package launcher;

import ui.GeheimSchriftUI;

public class CoderingLauncher {

    private static GeheimSchriftUI ui = new GeheimSchriftUI();

    public static void main(String args[])
    {
        ui.launch();
    }
}
