package domain;

public interface CodeerStrategy {

    public String encode(String tekst);

    public String decode(String tekst);

}
