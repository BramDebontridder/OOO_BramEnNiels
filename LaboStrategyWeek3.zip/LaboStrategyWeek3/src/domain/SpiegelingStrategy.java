package domain;

public class SpiegelingStrategy implements CodeerStrategy{

    public SpiegelingStrategy()
    {

    }

    public String encode(String msg)
    {
       return  new StringBuilder(msg).reverse().toString();
    }

    public String decode(String msg)
    {
       return new StringBuilder(msg).reverse().toString();
    }

    public static void main(String args[])
    {
        SpiegelingStrategy s = new SpiegelingStrategy();
        System.out.println(s.encode("hallo bram"));
        System.out.println(s.decode(s.encode("hallo bram")));

    }
}
