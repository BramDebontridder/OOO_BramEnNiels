package domain;

import java.util.ArrayList;

public class GeheimSchrift implements CodeerStrategy{

    private CodeerStrategy strategy;
    private String tekst;

    public GeheimSchrift(String zin)
    {
        this.setZin(zin);
    }

    public void setZin(String tekst)
    {
        this.tekst=tekst;
    }

    public String getZin()
    {
        return tekst;
    }

    public CodeerStrategy getState()
    {
        return strategy;
    }

    public void setState(CodeerStrategy strat)
    {
        this.strategy=strat;
    }


    @Override
    public String encode(String tekst) {
        return this.strategy.encode(tekst);
    }

    @Override
    public String decode(String tekst) {
        return this.strategy.decode(tekst);
    }

    public static void main(String args[])
    {
        GeheimSchrift schrift = new GeheimSchrift("hallo");
        schrift.setState(new CaesarStrategy());
        System.out.println(schrift.decode(schrift.getZin()));
    }
}
