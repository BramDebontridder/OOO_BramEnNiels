package ui;

import domain.CaesarStrategy;
import domain.CodeerStrategy;
import domain.GeheimSchrift;
import domain.SpiegelingStrategy;

import javax.swing.*;

public class GeheimSchriftUI {
    private String zin = "";
    private GeheimSchrift geheim = new GeheimSchrift(zin);
    private CodeerStrategy ceasar = new CaesarStrategy();
    private CodeerStrategy mirror = new SpiegelingStrategy();

    public GeheimSchriftUI()
    {

    }

    public void launch()
    {
        String tekst = JOptionPane.showInputDialog("Geef de zin in die je wil omzetten");
        geheim.setZin(tekst);
        String strategy = JOptionPane.showInputDialog("Geef aan welke strategy je wil gebruiken\n1. Ceaser Strategy\n2. Mirror Strategy\n\n0. Quit ");
        int strategyChoice = -1;
        while(strategyChoice !=0)
        {
            strategyChoice = Integer.parseInt(strategy);
            switch(strategyChoice)
            {
                case 0: break;
                case 1: this.ChooseCodingCeaser();break;
                case 2: this.ChooseCodingMirror();break;

            }
        }


    }

    private void ChooseCodingCeaser()
    {
        String option = JOptionPane.showInputDialog("1. Encode\n2. Decode");
        geheim.setState(ceasar);
        String result ="";

        if(option.equals("1"))
        {
            result=geheim.encode(geheim.getZin());
        }

        else if(option.equals("2"))
        {
            result=geheim.decode(geheim.getZin());
        }

        JOptionPane.showMessageDialog(null,result);
    }

    private void ChooseCodingMirror()
    {
        String option = JOptionPane.showInputDialog("1. Encode\n2. Decode");
        geheim.setState(mirror);
        String result ="";

        if(option.equals("1"))
        {
            result=geheim.encode(geheim.getZin());
        }

        else if(option.equals("2"))
        {
            result=geheim.decode(geheim.getZin());
        }

        JOptionPane.showMessageDialog(null,result);
    }
}
